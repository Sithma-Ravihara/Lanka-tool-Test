"use client"

import React, { useState } from 'react'
import { MobileShell } from '@/components/MobileShell'
import { Dashboard } from '@/components/Dashboard'
import { TranslateTool } from '@/components/tools/TranslateTool'
import { ServiceDirectory } from '@/components/tools/ServiceDirectory'
import { CurrencyPulse } from '@/components/tools/CurrencyPulse'
import { BillEstimator } from '@/components/tools/BillEstimator'
import { LankaDiary } from '@/components/tools/LankaDiary'
import { PersonalNotes } from '@/components/tools/PersonalNotes'
import { Toaster } from '@/components/ui/toaster'
import { ChevronLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function Home() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [selectedTool, setSelectedTool] = useState<string | null>(null)

  const handleToolSelect = (id: string) => {
    setSelectedTool(id)
  }

  const renderContent = () => {
    // If a tool is selected via the dashboard, show it regardless of tab
    const viewId = selectedTool || activeTab

    switch (viewId) {
      case 'dashboard':
        return <Dashboard onToolSelect={handleToolSelect} />
      case 'translate':
        return <TranslateTool />
      case 'directory':
        return <ServiceDirectory />
      case 'currency':
        return <CurrencyPulse />
      case 'bill':
        return <BillEstimator />
      case 'diary':
        return <LankaDiary />
      case 'notes':
        return <PersonalNotes />
      case 'profile':
        return (
          <div className="p-8 text-center space-y-6">
            <div className="h-24 w-24 rounded-full bg-primary/10 mx-auto flex items-center justify-center border-4 border-primary/20">
               <span className="text-4xl font-headline font-bold text-primary">SR</span>
            </div>
            <div className="space-y-1">
              <h2 className="text-2xl font-headline font-bold">Sithma Ravihara</h2>
              <p className="text-muted-foreground text-sm">Application Developer</p>
            </div>
            <div className="pt-8 space-y-4">
               <div className="p-4 rounded-2xl bg-card border border-white/5 flex items-center justify-between">
                  <span className="text-sm font-medium">App Language</span>
                  <span className="text-sm font-bold text-primary">English</span>
               </div>
               <div className="p-4 rounded-2xl bg-card border border-white/5 flex items-center justify-between">
                  <span className="text-sm font-medium">Theme Mode</span>
                  <span className="text-sm font-bold text-primary">Dark Obsidian</span>
               </div>
               <div className="p-4 rounded-2xl bg-card border border-white/5 flex items-center justify-between">
                  <span className="text-sm font-medium">Version</span>
                  <span className="text-sm font-bold text-primary">1.0.0-PRO</span>
               </div>
            </div>
          </div>
        )
      default:
        return (
          <div className="p-12 text-center text-muted-foreground">
            <p>Tool under development. Stay tuned!</p>
            <Button 
              variant="link" 
              onClick={() => {setSelectedTool(null); setActiveTab('dashboard')}}
              className="mt-4 text-primary"
            >
              Back to Home
            </Button>
          </div>
        )
    }
  }

  return (
    <MobileShell activeTab={selectedTool ? 'none' : activeTab} setActiveTab={(tab) => {setSelectedTool(null); setActiveTab(tab)}}>
      {selectedTool && (
        <div className="px-4 pt-4 sticky top-0 z-40 bg-background/80 backdrop-blur-sm pb-2">
           <Button 
             variant="ghost" 
             size="sm" 
             onClick={() => setSelectedTool(null)}
             className="text-muted-foreground hover:text-primary pl-0"
           >
              <ChevronLeft className="h-4 w-4 mr-1" /> Back to Tools
           </Button>
        </div>
      )}
      {renderContent()}
      <Toaster />
    </MobileShell>
  )
}
