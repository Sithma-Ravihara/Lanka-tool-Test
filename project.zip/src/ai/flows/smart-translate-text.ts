'use server';
/**
 * @fileOverview An AI-powered translation tool that handles context-aware translations between English, Sinhala, and Tamil.
 *
 * - smartTranslateText - A function that handles the translation process.
 * - SmartTranslateTextInput - The input type for the smartTranslateText function.
 * - SmartTranslateTextOutput - The return type for the smartTranslateText function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SmartTranslateTextInputSchema = z.object({
  textToTranslate: z.string().describe('The text to be translated.'),
  sourceLanguage: z
    .enum(['English', 'Sinhala', 'Tamil'])
    .describe('The original language of the text. Can be English, Sinhala, or Tamil.'),
  targetLanguage: z
    .enum(['English', 'Sinhala', 'Tamil'])
    .describe('The language to translate the text into. Can be English, Sinhala, or Tamil.'),
  context: z.string().optional().describe('Optional: Additional context to improve translation accuracy.'),
});
export type SmartTranslateTextInput = z.infer<typeof SmartTranslateTextInputSchema>;

const SmartTranslateTextOutputSchema = z.object({
  translatedText: z.string().describe('The translated text in the target language.'),
  detectedSourceLanguage: z
    .enum(['English', 'Sinhala', 'Tamil'])
    .optional()
    .describe('The detected source language, if it was not explicitly provided or if confirmation is needed.'),
});
export type SmartTranslateTextOutput = z.infer<typeof SmartTranslateTextOutputSchema>;

export async function smartTranslateText(
  input: SmartTranslateTextInput
): Promise<SmartTranslateTextOutput> {
  return smartTranslateTextFlow(input);
}

const smartTranslateTextPrompt = ai.definePrompt({
  name: 'smartTranslateTextPrompt',
  input: {schema: SmartTranslateTextInputSchema},
  output: {schema: SmartTranslateTextOutputSchema},
  prompt: `You are an expert multilingual translator specializing in English, Sinhala, and Tamil.
Your task is to translate the provided text from the source language to the target language, taking into account any given context to ensure an accurate and culturally appropriate translation.

Source Language: {{{sourceLanguage}}}
Target Language: {{{targetLanguage}}}
Text to Translate: {{{textToTranslate}}}

{{#if context}}
Additional Context: {{{context}}}
{{/if}}

Please provide the translation in the target language. If the source language was not explicitly provided or needs confirmation, please detect and output it.`,
});

const smartTranslateTextFlow = ai.defineFlow(
  {
    name: 'smartTranslateTextFlow',
    inputSchema: SmartTranslateTextInputSchema,
    outputSchema: SmartTranslateTextOutputSchema,
  },
  async input => {
    const {output} = await smartTranslateTextPrompt(input);
    return output!;
  }
);
