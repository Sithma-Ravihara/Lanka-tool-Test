import { config } from 'dotenv';
config();

import '@/ai/flows/smart-translate-text.ts';