"use client"

import React, { useState, useEffect } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Banknote, TrendingUp, TrendingDown, RefreshCw, Calculator, DollarSign } from 'lucide-react'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'

const MOCK_DATA = [
  { name: 'Mon', rate: 310.2 },
  { name: 'Tue', rate: 311.5 },
  { name: 'Wed', rate: 309.8 },
  { name: 'Thu', rate: 310.4 },
  { name: 'Fri', rate: 312.1 },
  { name: 'Sat', rate: 311.9 },
  { name: 'Sun', rate: 311.8 },
]

export function CurrencyPulse() {
  const [usdAmount, setUsdAmount] = useState<number>(1)
  const currentRate = 311.85
  const [isRefreshing, setIsRefreshing] = useState(false)

  const handleRefresh = () => {
    setIsRefreshing(true)
    setTimeout(() => setIsRefreshing(false), 800)
  }

  return (
    <div className="p-6 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <header className="flex justify-between items-start">
        <div>
          <h2 className="text-2xl font-headline font-bold">Currency Pulse</h2>
          <p className="text-muted-foreground text-sm">USD to LKR Exchange Rates</p>
        </div>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={handleRefresh}
          className={isRefreshing ? 'animate-spin' : ''}
        >
          <RefreshCw className="h-5 w-5" />
        </Button>
      </header>

      <Card className="bg-primary/10 border-primary/20 p-6 relative overflow-hidden">
        <div className="absolute top-[-10%] right-[-5%] opacity-5 text-primary rotate-12">
           <Banknote className="h-32 w-32" />
        </div>
        <div className="space-y-1 relative z-10">
          <div className="flex items-center gap-2 mb-1">
            <Badge className="bg-primary text-primary-foreground font-bold">USD/LKR</Badge>
            <span className="flex items-center text-xs text-emerald-500 font-bold">
               <TrendingDown className="h-3 w-3 mr-1" /> -0.25% Today
            </span>
          </div>
          <h3 className="text-4xl font-headline font-bold text-primary">Rs. {currentRate}</h3>
          <p className="text-xs text-muted-foreground">Updated: Few moments ago (CBSL Selling Rate)</p>
        </div>
      </Card>

      <div className="h-40 w-full mt-2">
         <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={MOCK_DATA}>
              <defs>
                <linearGradient id="colorRate" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="name" hide />
              <YAxis hide domain={['dataMin - 1', 'dataMax + 1']} />
              <Tooltip 
                contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px' }}
                itemStyle={{ color: 'hsl(var(--primary))' }}
              />
              <Area type="monotone" dataKey="rate" stroke="hsl(var(--primary))" fillOpacity={1} fill="url(#colorRate)" />
            </AreaChart>
         </ResponsiveContainer>
      </div>

      <div className="space-y-4 pt-2">
        <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground flex items-center gap-2">
           <Calculator className="h-4 w-4" /> Quick Converter
        </h3>
        <div className="flex items-center gap-3">
          <div className="flex-1 relative">
            <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              type="number" 
              className="pl-9 bg-card/50 border-white/5 h-12 text-lg font-semibold"
              value={usdAmount}
              onChange={(e) => setUsdAmount(Number(e.target.value))}
            />
          </div>
          <div className="flex-[1.5] bg-card/50 border border-white/5 h-12 rounded-lg flex items-center px-4 justify-between">
            <span className="text-xs font-bold text-muted-foreground mr-2">Rs.</span>
            <span className="text-lg font-bold text-primary">{(usdAmount * currentRate).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>
        </div>
      </div>
    </div>
  )
}
