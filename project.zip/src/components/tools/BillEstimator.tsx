"use client"

import React, { useState, useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Zap, Droplets, Info, Calculator } from 'lucide-react'
import { Progress } from '@/components/ui/progress'

export function BillEstimator() {
  const [cebUnits, setCebUnits] = useState<number>(0)
  const [nwsdbUnits, setNwsdbUnits] = useState<number>(0)

  const cebEstimate = useMemo(() => {
    let cost = 0
    let fixed = 0
    const units = cebUnits

    if (units <= 30) {
      cost = units * 8
      fixed = 150
    } else if (units <= 60) {
      cost = (30 * 8) + (units - 30) * 20
      fixed = 300
    } else if (units <= 90) {
      cost = (60 * 20) + (units - 60) * 37
      fixed = 480
    } else if (units <= 120) {
      cost = (90 * 37) + (units - 90) * 50
      fixed = 1000
    } else {
      cost = (120 * 50) + (units - 120) * 75
      fixed = 1500
    }
    return cost + fixed
  }, [cebUnits])

  const waterEstimate = useMemo(() => {
    let cost = 0
    let fixed = 500 // Base service charge approx
    const units = nwsdbUnits
    
    if (units <= 15) cost = units * 40
    else if (units <= 25) cost = (15 * 40) + (units - 15) * 80
    else cost = (25 * 80) + (units - 25) * 120

    return cost + fixed
  }, [nwsdbUnits])

  return (
    <div className="p-6 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <header>
        <h2 className="text-2xl font-headline font-bold">Bill Estimator</h2>
        <p className="text-muted-foreground text-sm">Domestic utility slab rates (Estimated)</p>
      </header>

      <Tabs defaultValue="ceb" className="w-full">
        <TabsList className="w-full grid grid-cols-2 bg-card/50 border border-white/5 p-1 h-12">
          <TabsTrigger value="ceb" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground h-full rounded-lg">
            <Zap className="h-4 w-4 mr-2" /> CEB
          </TabsTrigger>
          <TabsTrigger value="nwsdb" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground h-full rounded-lg">
            <Droplets className="h-4 w-4 mr-2" /> NWSDB
          </TabsTrigger>
        </TabsList>

        <TabsContent value="ceb" className="mt-6 space-y-6">
          <div className="space-y-4">
            <Label className="text-sm font-medium">Monthly Unit Consumption (kWh)</Label>
            <div className="relative">
              <Input 
                type="number" 
                placeholder="0" 
                className="h-14 text-2xl font-bold bg-card/50 border-white/5 focus-visible:ring-primary/50 pl-4 pr-16"
                value={cebUnits || ''}
                onChange={(e) => setCebUnits(Number(e.target.value))}
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 font-medium text-muted-foreground">kWh</span>
            </div>
            <Progress value={Math.min((cebUnits / 200) * 100, 100)} className="h-1 bg-white/5" />
          </div>

          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-6 text-center space-y-1">
              <p className="text-xs uppercase font-bold tracking-widest text-primary/70">Estimated Monthly Bill</p>
              <h3 className="text-4xl font-headline font-bold text-primary">Rs. {cebEstimate.toLocaleString()}</h3>
              <p className="text-[10px] text-muted-foreground pt-2">Includes fixed charges and fuel adjustments.</p>
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 gap-3">
             <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                <p className="text-[10px] uppercase text-muted-foreground mb-1">Current Slab</p>
                <p className="font-semibold">{cebUnits <= 60 ? 'Low' : cebUnits <= 120 ? 'Standard' : 'High Usage'}</p>
             </div>
             <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                <p className="text-[10px] uppercase text-muted-foreground mb-1">Tax Estimate</p>
                <p className="font-semibold">~ Rs. {(cebEstimate * 0.18).toFixed(0)} (VAT)</p>
             </div>
          </div>
        </TabsContent>

        <TabsContent value="nwsdb" className="mt-6 space-y-6">
          <div className="space-y-4">
            <Label className="text-sm font-medium">Monthly Consumption (Units/m³)</Label>
            <div className="relative">
              <Input 
                type="number" 
                placeholder="0" 
                className="h-14 text-2xl font-bold bg-card/50 border-white/5 focus-visible:ring-primary/50 pl-4 pr-16"
                value={nwsdbUnits || ''}
                onChange={(e) => setNwsdbUnits(Number(e.target.value))}
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 font-medium text-muted-foreground">Units</span>
            </div>
            <Progress value={Math.min((nwsdbUnits / 50) * 100, 100)} className="h-1 bg-white/5" />
          </div>

          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-6 text-center space-y-1">
              <p className="text-xs uppercase font-bold tracking-widest text-primary/70">Estimated Water Bill</p>
              <h3 className="text-4xl font-headline font-bold text-primary">Rs. {waterEstimate.toLocaleString()}</h3>
              <p className="text-[10px] text-muted-foreground pt-2">Domestic usage estimate based on standard tariff.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="bg-accent/10 p-4 rounded-xl flex items-start gap-3 border border-accent/20">
        <Info className="h-5 w-5 text-accent shrink-0 mt-0.5" />
        <p className="text-xs text-accent-foreground leading-relaxed">
          Disclaimer: This is a rough estimation based on recent publicly available slab rates. Actual bills may include additional levies, SSCL, and VAT which are subject to change by utility regulators.
        </p>
      </div>
    </div>
  )
}
