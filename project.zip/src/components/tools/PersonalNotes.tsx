"use client"

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Cloud, Plus, Trash2, Copy, Lock, ShieldCheck, FileText } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface Note {
  id: string
  title: string
  content: string
  category: string
}

export function PersonalNotes() {
  const [notes, setNotes] = useState<Note[]>([])
  const [newTitle, setNewTitle] = useState('')
  const [newContent, setNewContent] = useState('')
  const { toast } = useToast()

  useEffect(() => {
    const saved = localStorage.getItem('sr_lankahub_notes')
    if (saved) setNotes(JSON.parse(saved))
  }, [])

  const saveNotes = (updated: Note[]) => {
    setNotes(updated)
    localStorage.setItem('sr_lankahub_notes', JSON.stringify(updated))
  }

  const addNote = () => {
    if (!newTitle || !newContent) return
    const note: Note = {
      id: Date.now().toString(),
      title: newTitle,
      content: newContent,
      category: 'General'
    }
    saveNotes([note, ...notes])
    setNewTitle('')
    setNewContent('')
    toast({ description: "Note saved securely." })
  }

  const deleteNote = (id: string) => {
    saveNotes(notes.filter(n => n.id !== id))
    toast({ description: "Note deleted." })
  }

  const copyNote = (content: string) => {
    navigator.clipboard.writeText(content)
    toast({ description: "Copied to clipboard" })
  }

  return (
    <div className="p-6 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <header className="flex justify-between items-start">
        <div>
          <h2 className="text-2xl font-headline font-bold">Personal Cloud</h2>
          <p className="text-muted-foreground text-sm">Securely store IDs and registrations</p>
        </div>
        <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center text-accent">
          <Lock className="h-5 w-5" />
        </div>
      </header>

      <Card className="bg-card/50 border-white/5 p-4 space-y-3">
        <Input 
          placeholder="Title (e.g. NIC Number, Vehicle No)" 
          className="bg-background/50 border-white/5 h-11"
          value={newTitle}
          onChange={(e) => setNewTitle(e.target.value)}
        />
        <Input 
          placeholder="Value / Content" 
          className="bg-background/50 border-white/5 h-11"
          value={newContent}
          onChange={(e) => setNewContent(e.target.value)}
        />
        <Button 
          className="w-full h-11 bg-primary text-primary-foreground font-bold"
          onClick={addNote}
        >
          <Plus className="h-4 w-4 mr-2" /> Add to Secure Cloud
        </Button>
      </Card>

      <div className="space-y-4">
        <div className="flex items-center gap-2 text-muted-foreground text-xs uppercase font-bold tracking-widest px-1">
          <ShieldCheck className="h-3 w-3" /> Encrypted Local Storage
        </div>
        
        {notes.length === 0 ? (
          <div className="py-12 text-center text-muted-foreground/40 space-y-2">
            <Cloud className="h-12 w-12 mx-auto mb-2" />
            <p>Your cloud is empty. Start adding secure notes.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {notes.map((note) => (
              <Card key={note.id} className="bg-card/50 border-white/5 overflow-hidden group">
                <CardContent className="p-4 flex items-center justify-between gap-4">
                  <div className="flex-1 space-y-1">
                    <h4 className="text-sm font-bold text-primary uppercase">{note.title}</h4>
                    <p className="text-lg font-mono tracking-tight">{note.content}</p>
                  </div>
                  <div className="flex items-center gap-1 opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="icon" onClick={() => copyNote(note.content)} className="h-10 w-10 text-muted-foreground hover:text-primary hover:bg-primary/10">
                      <Copy className="h-5 w-5" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => deleteNote(note.id)} className="h-10 w-10 text-muted-foreground hover:text-destructive hover:bg-destructive/10">
                      <Trash2 className="h-5 w-5" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
