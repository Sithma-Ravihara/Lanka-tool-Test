"use client"

import React, { useState } from 'react'
import { Calendar } from '@/components/ui/calendar'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Moon, Star, CalendarDays, MapPin } from 'lucide-react'
import { format } from 'date-fns'

const POYA_DAYS_2024 = [
  { date: new Date(2024, 0, 25), name: 'Duruthu Full Moon Poya' },
  { date: new Date(2024, 1, 24), name: 'Navam Full Moon Poya' },
  { date: new Date(2024, 2, 24), name: 'Madin Full Moon Poya' },
  { date: new Date(2024, 3, 23), name: 'Bak Full Moon Poya' },
  { date: new Date(2024, 4, 23), name: 'Vesak Full Moon Poya' },
  { date: new Date(2024, 5, 21), name: 'Poson Full Moon Poya' },
  { date: new Date(2024, 6, 21), name: 'Esala Full Moon Poya' },
  { date: new Date(2024, 7, 19), name: 'Nikini Full Moon Poya' },
  { date: new Date(2024, 8, 17), name: 'Binara Full Moon Poya' },
  { date: new Date(2024, 9, 17), name: 'Vap Full Moon Poya' },
  { date: new Date(2024, 10, 15), name: 'Il Full Moon Poya' },
  { date: new Date(2024, 11, 15), name: 'Unduvap Full Moon Poya' },
]

export function LankaDiary() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  const selectedPoya = POYA_DAYS_2024.find(
    p => p.date.toDateString() === date?.toDateString()
  )

  const modifiers = {
    poya: POYA_DAYS_2024.map(p => p.date)
  }

  const modifierStyles = {
    poya: { 
      fontWeight: 'bold', 
      backgroundColor: 'hsl(var(--primary))', 
      color: 'hsl(var(--primary-foreground))',
      borderRadius: '50%'
    }
  }

  return (
    <div className="p-6 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <header>
        <h2 className="text-2xl font-headline font-bold">Lanka Diary</h2>
        <p className="text-muted-foreground text-sm">Poya days and traditional Nekath times</p>
      </header>

      <Card className="bg-card/50 border-white/5 shadow-inner">
        <CardContent className="p-3 flex justify-center">
          <Calendar
            mode="single"
            selected={date}
            onSelect={setDate}
            className="rounded-xl"
            modifiers={modifiers}
            modifiersStyles={modifierStyles}
          />
        </CardContent>
      </Card>

      <div className="space-y-4">
        <h3 className="font-semibold flex items-center gap-2">
          <CalendarDays className="h-4 w-4 text-primary" />
          {date ? format(date, 'MMMM d, yyyy') : 'Selected Date'}
        </h3>
        
        {selectedPoya ? (
          <Card className="bg-primary/10 border-primary/30 animate-in zoom-in-95">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-full bg-primary flex items-center justify-center text-primary-foreground shadow-lg shadow-primary/20">
                <Moon className="h-6 w-6" />
              </div>
              <div>
                <Badge variant="default" className="bg-primary text-primary-foreground mb-1">Poya Day</Badge>
                <h4 className="font-bold text-lg leading-tight">{selectedPoya.name}</h4>
                <p className="text-xs text-muted-foreground">Public, Bank & Mercantile Holiday</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="bg-card/30 border-white/5 border-dashed">
            <CardContent className="p-8 text-center text-muted-foreground">
              <Star className="h-8 w-8 mx-auto mb-3 opacity-20" />
              <p className="text-sm">Standard working day. No specific local holidays found for this date.</p>
            </CardContent>
          </Card>
        )}
      </div>

      <div className="space-y-3">
        <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Upcoming Poya Days</h3>
        <div className="space-y-2">
          {POYA_DAYS_2024.filter(p => p.date >= new Date()).slice(0, 3).map((p, idx) => (
            <div key={idx} className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5">
              <span className="text-sm font-medium">{p.name}</span>
              <span className="text-xs font-mono text-primary">{format(p.date, 'MMM dd')}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
