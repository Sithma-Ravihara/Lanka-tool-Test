"use client"

import React, { useState } from 'react'
import { smartTranslateText } from '@/ai/flows/smart-translate-text'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Globe, ArrowRightLeft, Copy, Loader2, Languages } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

export function TranslateTool() {
  const [text, setText] = useState('')
  const [sourceLang, setSourceLang] = useState<'English' | 'Sinhala' | 'Tamil'>('English')
  const [targetLang, setTargetLang] = useState<'English' | 'Sinhala' | 'Tamil'>('Sinhala')
  const [result, setResult] = useState('')
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const handleTranslate = async () => {
    if (!text.trim()) return
    setLoading(true)
    try {
      const response = await smartTranslateText({
        textToTranslate: text,
        sourceLanguage: sourceLang,
        targetLanguage: targetLang,
      })
      setResult(response.translatedText)
    } catch (error) {
      toast({
        title: "Translation Error",
        description: "Could not complete the translation. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const swapLanguages = () => {
    setSourceLang(targetLang)
    setTargetLang(sourceLang)
  }

  const copyToClipboard = (val: string) => {
    navigator.clipboard.writeText(val)
    toast({ description: "Copied to clipboard" })
  }

  return (
    <div className="p-6 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <header>
        <h2 className="text-2xl font-headline font-bold">Smart Translate</h2>
        <p className="text-muted-foreground text-sm">AI-powered context-aware translation</p>
      </header>

      <Card className="border-white/5 bg-card/50 overflow-hidden">
        <CardContent className="p-4 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <Select value={sourceLang} onValueChange={(v: any) => setSourceLang(v)}>
              <SelectTrigger className="bg-background/50 border-white/5 h-10">
                <SelectValue placeholder="Source" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="English">English</SelectItem>
                <SelectItem value="Sinhala">Sinhala</SelectItem>
                <SelectItem value="Tamil">Tamil</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="ghost" size="icon" onClick={swapLanguages} className="shrink-0 hover:bg-primary/10 hover:text-primary transition-colors">
              <ArrowRightLeft className="h-4 w-4" />
            </Button>

            <Select value={targetLang} onValueChange={(v: any) => setTargetLang(v)}>
              <SelectTrigger className="bg-background/50 border-white/5 h-10">
                <SelectValue placeholder="Target" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="English">English</SelectItem>
                <SelectItem value="Sinhala">Sinhala</SelectItem>
                <SelectItem value="Tamil">Tamil</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="relative">
            <Textarea
              placeholder="Enter text here..."
              className="min-h-[120px] bg-background/50 border-white/5 focus-visible:ring-primary/50 text-base"
              value={text}
              onChange={(e) => setText(e.target.value)}
            />
            {text && (
              <Button 
                variant="ghost" 
                size="icon" 
                className="absolute top-2 right-2 h-8 w-8 text-muted-foreground"
                onClick={() => setText('')}
              >
                <span className="sr-only">Clear</span>
                ×
              </Button>
            )}
          </div>

          <Button 
            className="w-full h-12 text-base font-semibold shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-[0.98] transition-all bg-primary hover:bg-primary/90 text-primary-foreground" 
            onClick={handleTranslate}
            disabled={loading || !text}
          >
            {loading ? (
              <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Translating...</>
            ) : (
              <><Languages className="mr-2 h-5 w-5" /> Translate Now</>
            )}
          </Button>
        </CardContent>
      </Card>

      {result && (
        <Card className="border-primary/20 bg-primary/5 animate-in zoom-in-95 duration-200">
          <CardHeader className="py-3 px-4 border-b border-primary/10 flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-medium text-primary uppercase tracking-wider">Result</CardTitle>
            <Button variant="ghost" size="icon" onClick={() => copyToClipboard(result)} className="h-8 w-8 text-primary hover:bg-primary/20">
              <Copy className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent className="p-4">
            <p className="text-lg leading-relaxed">{result}</p>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-2 gap-4">
        <Card className="bg-card/30 border-white/5 p-4 flex flex-col items-center text-center gap-2">
          <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center text-accent">
            <Globe className="h-5 w-5" />
          </div>
          <span className="text-xs font-medium text-muted-foreground">Culturally Aware</span>
        </Card>
        <Card className="bg-card/30 border-white/5 p-4 flex flex-col items-center text-center gap-2">
          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
            <Languages className="h-5 w-5" />
          </div>
          <span className="text-xs font-medium text-muted-foreground">3 Local Languages</span>
        </Card>
      </div>
    </div>
  )
}
