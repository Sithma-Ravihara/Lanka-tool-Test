"use client"

import React, { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Search, Phone, Shield, HeartPulse, Zap, Droplets, Info, ExternalLink } from 'lucide-react'
import { Button } from '@/components/ui/button'

const SERVICES = [
  { name: 'Police Emergency', number: '119', category: 'Emergency', icon: Shield, color: 'text-red-500' },
  { name: 'Ambulance (Suwa Seriya)', number: '1990', category: 'Emergency', icon: HeartPulse, color: 'text-primary' },
  { name: 'Fire & Rescue (Colombo)', number: '011-2422222', category: 'Emergency', icon: Shield, color: 'text-orange-500' },
  { name: 'Government Info Center', number: '1919', category: 'Public', icon: Info, color: 'text-blue-500' },
  { name: 'CEB (Electricity)', number: '1987', category: 'Utilities', icon: Zap, color: 'text-yellow-500' },
  { name: 'LECO (Electricity)', number: '1901', category: 'Utilities', icon: Zap, color: 'text-yellow-600' },
  { name: 'NWSDB (Water)', number: '1939', category: 'Utilities', icon: Droplets, color: 'text-cyan-500' },
  { name: 'Child Protection', number: '1929', category: 'Social', icon: HeartPulse, color: 'text-pink-500' },
  { name: 'Accident Ward (Colombo)', number: '011-2691111', category: 'Medical', icon: HeartPulse, color: 'text-red-400' },
  { name: 'Consumer Affairs', number: '1977', category: 'Public', icon: Info, color: 'text-emerald-500' },
]

export function ServiceDirectory() {
  const [query, setQuery] = useState('')

  const filtered = SERVICES.filter(s => 
    s.name.toLowerCase().includes(query.toLowerCase()) || 
    s.number.includes(query) ||
    s.category.toLowerCase().includes(query.toLowerCase())
  )

  return (
    <div className="p-6 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <header>
        <h2 className="text-2xl font-headline font-bold">Service Directory</h2>
        <p className="text-muted-foreground text-sm">Essential hotlines for every Sri Lankan</p>
      </header>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input 
          placeholder="Search by service, category or number..." 
          className="pl-10 bg-card/50 border-white/5 h-12 focus-visible:ring-primary/50"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 gap-3">
        {filtered.map((service, idx) => {
          const Icon = service.icon
          return (
            <Card key={idx} className="bg-card/50 border-white/5 hover:border-primary/20 transition-all active:scale-[0.98]">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`h-12 w-12 rounded-2xl bg-white/5 flex items-center justify-center ${service.color}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-base">{service.name}</h3>
                    <p className="text-xs text-muted-foreground uppercase font-medium">{service.category}</p>
                  </div>
                </div>
                <Button 
                  asChild
                  className="h-10 px-4 bg-primary/10 hover:bg-primary text-primary hover:text-primary-foreground border-none rounded-xl"
                >
                  <a href={`tel:${service.number.replace(/-/g, '')}`}>
                    <Phone className="h-4 w-4 mr-2" />
                    {service.number}
                  </a>
                </Button>
              </CardContent>
            </Card>
          )
        })}
        {filtered.length === 0 && (
          <div className="py-12 text-center text-muted-foreground">
            <Info className="h-12 w-12 mx-auto mb-4 opacity-20" />
            <p>No matching services found.</p>
          </div>
        )}
      </div>
    </div>
  )
}
