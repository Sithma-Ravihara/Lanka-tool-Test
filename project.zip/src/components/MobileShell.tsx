"use client"

import React from 'react'
import { LayoutGrid, Search, User, Globe, MessageSquare } from 'lucide-react'
import { cn } from '@/lib/utils'

interface MobileShellProps {
  children: React.ReactNode
  activeTab: string
  setActiveTab: (tab: string) => void
}

export function MobileShell({ children, activeTab, setActiveTab }: MobileShellProps) {
  const navItems = [
    { id: 'dashboard', icon: LayoutGrid, label: 'Home' },
    { id: 'translate', icon: Globe, label: 'Translate' },
    { id: 'directory', icon: Search, label: 'Search' },
    { id: 'notes', icon: MessageSquare, label: 'Notes' },
    { id: 'profile', icon: User, label: 'Profile' },
  ]

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground max-w-md mx-auto relative shadow-2xl">
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-white/5 px-6 py-4 flex justify-between items-center">
        <div>
          <h1 className="text-xl font-headline font-bold text-primary leading-tight tracking-tight">SR LankaHub</h1>
          <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-medium">By Sithma Ravihara</p>
        </div>
        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
          <User className="h-5 w-5 text-primary" />
        </div>
      </header>

      <main className="flex-1 pb-24 overflow-y-auto no-scrollbar">
        {children}
      </main>

      <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto z-50 px-4 pb-4">
        <div className="bg-card/90 backdrop-blur-xl border border-white/5 rounded-2xl flex items-center justify-around py-3 px-2 shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.5)]">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = activeTab === item.id
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={cn(
                  "flex flex-col items-center gap-1 transition-all duration-200 px-3 py-1 rounded-xl",
                  isActive ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-foreground"
                )}
              >
                <Icon className={cn("h-6 w-6 transition-transform", isActive && "scale-110")} />
                <span className="text-[10px] font-medium">{item.label}</span>
              </button>
            )
          })}
        </div>
      </nav>
    </div>
  )
}
