"use client"

import React from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { 
  Languages, 
  Search, 
  Banknote, 
  Calculator, 
  Calendar, 
  Cloud, 
  Zap, 
  Droplets,
  Fuel,
  Car,
  ChevronRight,
  TrendingUp,
  MapPin,
  Clock,
  LayoutGrid
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface ToolItem {
  id: string
  name: string
  description: string
  icon: any
  color: string
  category: string
  featured?: boolean
}

const TOOLS: ToolItem[] = [
  { id: 'translate', name: 'Smart Translate', description: 'AI Translation Tool', icon: Languages, color: 'from-orange-500 to-amber-500', category: 'GenAI', featured: true },
  { id: 'currency', name: 'LKR Pulse', description: 'Exchange Rates', icon: Banknote, color: 'from-emerald-500 to-teal-500', category: 'Finance', featured: true },
  { id: 'directory', name: 'Service Directory', description: 'Important Hotlines', icon: Search, color: 'from-blue-500 to-indigo-500', category: 'Essential' },
  { id: 'bill', name: 'Bill Estimator', description: 'CEB/Water Slabs', icon: Calculator, color: 'from-rose-500 to-pink-500', category: 'Utilities' },
  { id: 'diary', name: 'Lanka Diary', description: 'Poya & Holidays', icon: Calendar, color: 'from-purple-500 to-violet-500', category: 'Tradition' },
  { id: 'notes', name: 'Personal Cloud', description: 'Secure Info Vault', icon: Cloud, color: 'from-slate-500 to-gray-500', category: 'Storage' },
  { id: 'fuel', name: 'Fuel Prices', description: 'Latest QR Updates', icon: Fuel, color: 'from-red-500 to-orange-500', category: 'Travel' },
  { id: 'vehicle', name: 'Vehicle Revenue', description: 'Renewal Checker', icon: Car, color: 'from-cyan-500 to-sky-500', category: 'Gov' },
]

interface DashboardProps {
  onToolSelect: (id: string) => void
}

export function Dashboard({ onToolSelect }: DashboardProps) {
  return (
    <div className="p-6 space-y-8 animate-in fade-in duration-500">
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-headline font-bold">Featured Tools</h2>
          <span className="text-primary text-[10px] font-bold uppercase tracking-widest">See all</span>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          {TOOLS.filter(t => t.featured).map((tool) => {
            const Icon = tool.icon
            return (
              <Card 
                key={tool.id} 
                onClick={() => onToolSelect(tool.id)}
                className="group cursor-pointer border-white/5 bg-card/40 hover:bg-card/60 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <CardContent className="p-5 space-y-3">
                  <div className={cn("h-12 w-12 rounded-2xl bg-gradient-to-br flex items-center justify-center text-white shadow-lg", tool.color)}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm leading-tight">{tool.name}</h3>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{tool.description}</p>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </section>

      <section className="bg-primary/5 rounded-2xl border border-primary/20 p-5 flex items-center gap-4 overflow-hidden relative">
         <div className="flex-1 space-y-1 relative z-10">
            <h3 className="font-headline font-bold text-primary flex items-center gap-2">
              <TrendingUp className="h-4 w-4" /> Market Pulse
            </h3>
            <p className="text-[11px] text-muted-foreground">USD Selling: Rs. 311.85</p>
         </div>
         <div className="relative z-10">
            <LayoutGrid className="h-10 w-10 text-primary opacity-20" />
         </div>
         <div className="absolute top-0 right-0 h-full w-24 bg-gradient-to-l from-primary/10 to-transparent pointer-events-none" />
      </section>

      <section className="space-y-4">
        <h2 className="text-xl font-headline font-bold">Utility Hub</h2>
        <div className="space-y-3">
          {TOOLS.filter(t => !t.featured).map((tool) => {
            const Icon = tool.icon
            return (
              <Card 
                key={tool.id} 
                onClick={() => onToolSelect(tool.id)}
                className="group cursor-pointer border-white/5 bg-card/40 hover:bg-card/60 transition-all active:scale-[0.98]"
              >
                <CardContent className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={cn("h-12 w-12 rounded-xl bg-gradient-to-br flex items-center justify-center text-white", tool.color)}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm">{tool.name}</h3>
                      <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-medium">{tool.category}</p>
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                </CardContent>
              </Card>
            )
          })}
        </div>
      </section>

      <footer className="py-8 text-center space-y-2 opacity-30">
        <p className="text-xs font-headline font-medium">SR LankaHub v1.0.0</p>
        <p className="text-[10px] uppercase tracking-widest font-bold">Developed with ❤️ for Sri Lanka</p>
      </footer>
    </div>
  )
}
