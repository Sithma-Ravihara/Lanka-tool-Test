# **App Name**: SR LankaHub

## Core Features:

- Smart Translate Tool: An AI-powered translation tool that handles context-aware translations between English, Sinhala, and Tamil.
- Essential Service Directory: A searchable database of important Sri Lankan hotlines for hospitals, emergency services, and public utilities.
- LKR Currency Pulse: Real-time exchange rates with local LKR history and conversion tool using an external financial API.
- Domestic Bill Estimator: Calculator to estimate monthly CEB and NWSDB bills based on the latest local slab rates.
- Lanka Diary & Nekath: Daily calendar highlighting local Poya days and traditional Nekath times.
- Personal Note Cloud: Users can save frequently used registration numbers or personal data securely to the database.
- Unified Toolset Dashboard: A clean, grid-based layout for quick access to all utilities designed for high performance on Android devices.

## Style Guidelines:

- Primary color: Golden Amber (#FB9B1E), inspired by the vibrant warmth of Sri Lankan spices and sunshine.
- Background color: Deep Obsidian Clay (#231F1A), a dark, low-fatigue scheme designed for use in any lighting.
- Accent color: Tropical Coral (#E62E1A) for call-to-actions and high-visibility status indicators.
- Headline font: 'Space Grotesk' for a computerized, techy feel; Body font: 'Inter' for neutral readability in small screen formats.
- Minimalist line icons that represent daily Sri Lankan utilities such as bill logos and public service symbols.
- Card-based dashboard focused on accessibility and one-handed operation on mobile browsers.
- Quick, energetic transitions (200ms) between utility tools to ensure the app feels snappy and lightweight.